Andrew Cvitanovich

Problem 1.1: python problem1-1.py input.txt
Problem 1.2: python problem1-2.py input2.txt
