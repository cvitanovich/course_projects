Andrew Cvitanovich

Problem 2.1: python problem2-1.py input2-1.txt
Problem 2.2: python problem2-2.py input2-2.txt
Problem 2.3: python problem2-3.py input2-3.txt
